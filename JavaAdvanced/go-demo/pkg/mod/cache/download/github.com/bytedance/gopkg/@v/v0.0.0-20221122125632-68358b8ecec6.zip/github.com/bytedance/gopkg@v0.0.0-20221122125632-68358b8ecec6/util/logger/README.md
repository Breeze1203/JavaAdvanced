# logger

`logger` is the package which provides logging functions for all the utilities in gopkg.